package com.cg.empservice;

import static org.junit.Assert.*;

import org.junit.Test;

public class ValidatorTest {

	
	
	@Test
	public void testIsValidEmployeeName() {
		//assert.true(new Validator().isValidEmployeeName("ghjgjk"));
	assertTrue(new Validator().isValidEmployeeName("SamSDlF"));
	
	}

}
