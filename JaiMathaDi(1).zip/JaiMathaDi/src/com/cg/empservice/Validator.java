package com.cg.empservice;

import java.util.regex.Pattern;

public class Validator {
	
	public Validator(){
		
	}
	
	
	public Boolean isValidEmployeeName(String empname){
		String regex="^[A-Z]{1}[a-z]{2}[A-Z]{3,4}$";
		 //String regex1="^[a-zA-Z]+(.)?([a-zA-Z]+)?(\\s)?(([a-zA-Z])+)?$";
		 
		 
	return Pattern.matches(regex,empname);
		
	}

}
