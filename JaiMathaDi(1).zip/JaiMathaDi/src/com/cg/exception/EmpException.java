package com.cg.exception;

public class EmpException extends Exception{
	
	private static final long serialVersionUID = 1L;
	private String message;

	public EmpException() {
		super();
	}

	public EmpException(String message) {
		super();
		this.message = message;
	}
	
	

	@Override
	public String toString() {
		return "EmpException [message=" + message + "]";
	}

	public String getMessage() {
		return message;
	}

}
