package com.cg.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.bean.EmpBean;
import com.cg.exception.EmpException;





public interface IEmpDao {

	Boolean addEmployeeDetails(EmpBean emplo) throws SQLException, EmpException;

	List<EmpBean> displayEmployeeDetails() throws EmpException;

	

	void deleteEmployeeDetails(Integer empid1) throws SQLException, EmpException;

	void updateSalary(String saly, int empid2) throws SQLException, EmpException;

	

	
	
}

