package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.bean.EmpBean;
import com.cg.db.DBConnection;
import com.cg.exception.EmpException;

public class EmpDaoImpl implements IEmpDao{
	@Override
	public Boolean addEmployeeDetails(EmpBean emplo) throws SQLException, EmpException {
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.ADD_EMPLOYEE_DETAILS);
				Statement statement = connection.createStatement();
				){

			//preparedStatement.setInt(1,emplo.getEmpid());
			preparedStatement.setString(1, emplo.getEmpname());
			preparedStatement.setInt(2,emplo.getEmpsal());
			preparedStatement.setInt(3,emplo.getEmpdept());
			
			int i=preparedStatement.executeUpdate();
			if(i>0){
				
				return true;
			}else{
				return false;
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<EmpBean> displayEmployeeDetails() throws EmpException {
		List<EmpBean> empList =new ArrayList<>();

		try(Connection connection=DBConnection.getConnection();
				Statement statement=connection.createStatement();
				){
			
			ResultSet resultSet=statement.executeQuery(QueryMapper. DISPLAY_EMP_DETAILS);
			while(resultSet.next()){
			EmpBean emp=new EmpBean();
				populateHotel(emp,resultSet);
				empList.add(emp);
				
				
			}
			
			return empList;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}

	private void populateHotel(EmpBean emp, ResultSet resultSet) throws SQLException {
		emp.setEmpid(resultSet.getInt("emp_id"));
		emp.setEmpname(resultSet.getString("emp_name"));
		emp.setEmpsal(resultSet.getInt("emp_sal"));
		emp.setEmpdept(resultSet.getInt("dept_id"));
	}

	@Override
	public void deleteEmployeeDetails(Integer empid1) throws SQLException, EmpException {
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.DELETE_EMP_DETAILS);
				Statement statement = connection.createStatement();
				){
			preparedStatement.setInt(1, empid1);
			int i=preparedStatement.executeUpdate();
			if(i>0){
				
				System.out.println("employee deleted");
			}else{
				System.out.println("Entered employee id doesn't exists");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
		
		
	}

	@Override
	public void updateSalary(String saly, int empid2) throws SQLException, EmpException {
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_SALARY);
				){

			
			preparedStatement.setInt(2, empid2);
			preparedStatement.setInt(1, Integer.parseInt(saly));
			
			preparedStatement.executeUpdate();
		
	}

}
}