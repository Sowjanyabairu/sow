package com.cg.view;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.bean.EmpBean;
import com.cg.empservice.EmpserviceImpl;
import com.cg.empservice.IEmpservice;
import com.cg.empservice.Validator;
import com.cg.exception.EmpException;



public class Client {
	private static Scanner sc=new Scanner(System.in);


	private static IEmpservice empService = new EmpserviceImpl();
	private static Validator validator = new Validator();
	public static void main(String[] args) {
		while(true){

			// show menu
			System.out.println("1.Inserting Emp Details into DB");
			System.out.println("2.Display Employees");
			System.out.println("3.Delete Employee");
			System.out.println("4.Update details");
			System.out.println("5.Exit");
			Integer option = sc.nextInt();

			switch (option) {

			case 1:
				/*System.out.println("Enter Employee Id");
				Integer empid = sc.nextInt();*/
				
				System.out.println("Enter Employee name");
				String empname = sc.next();
				if(validator.isValidEmployeeName(empname)){
				System.out.println("Enter emp sal");
				Integer empsal = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter dept name");
				Integer empdept= sc.nextInt();

				EmpBean emplo = new EmpBean(/*empid*/ empname, empsal, empdept);

				try {
					empService.addEmployeeDetails(emplo);
				} catch (SQLException e) {

					e.printStackTrace();
				} catch (EmpException e) {

					e.printStackTrace();
				}

				System.out.println("Insertion into db is successful");
				}else{
					System.out.println("enter valid emp name");
				}
				break;

			case 2:
				List<EmpBean> empList =new ArrayList<>();
				try {
					empList=empService.displayEmployeeDetails();
					showDetails(empList);
				} catch (EmpException e) {

					e.printStackTrace();
				}

				break;

			case 3:
				System.out.println("enter emloyee id to delete");
				int empid1 = sc.nextInt();
				
				try {
					empService.deleteEmployeeDetails(empid1);
				} catch (SQLException e) {
					
					e.printStackTrace();
				} catch (EmpException e) {
					
					e.printStackTrace();
				}
				break;


			case 4:
				EmpBean empset = new EmpBean();
				System.out.println("Enter employee id:");
				int empid2=sc.nextInt();
				System.out.println("Enter updated salary");
				String saly=sc.next();
				try {
					empService.updateSalary(saly, empid2);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;


			case 5:
				System.exit(0);
				break;
			default:
				break;
			}


		}

	}
	private static void showDetails(List<EmpBean> empList) {

		for(EmpBean b:empList){
			System.out.println(b);
		}
	}
}
