package com.cg.bean;

public class EmpBean {

	private Integer empid;

	private String empname;

	private Integer empsal;
	private Integer empdept;


	public EmpBean(){

	}


	public EmpBean(Integer empid, String empname, Integer empsal,
			Integer empdept) {
		super();
		this.empid = empid;
		this.empname = empname;
		this.empsal = empsal;
		this.empdept = empdept;
	}



	public EmpBean(String empname, Integer empsal, Integer empdept) {
		super();
		this.empname = empname;
		this.empsal = empsal;
		this.empdept = empdept;
	}


	public EmpBean(Integer empid, Integer empsal) {
		super();
		this.empid = empid;
		this.empsal = empsal;
	}


	public Integer getEmpid() {
		return empid;
	}


	public void setEmpid(Integer empid) {
		this.empid = empid;
	}


	public String getEmpname() {
		return empname;
	}


	public void setEmpname(String empname) {
		this.empname = empname;
	}


	public Integer getEmpsal() {
		return empsal;
	}


	public void setEmpsal(Integer empsal) {
		this.empsal = empsal;
	}


	public Integer getEmpdept() {
		return empdept;
	}


	public void setEmpdept(Integer empdept) {
		this.empdept = empdept;
	}


	@Override
	public String toString() {
		return "EmpBean [empid=" + empid + ", empname=" + empname + ", empsal="
				+ empsal + ", empdept=" + empdept + "]";
	}






}
