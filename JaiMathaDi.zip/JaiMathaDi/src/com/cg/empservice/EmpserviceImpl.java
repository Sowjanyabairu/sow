package com.cg.empservice;


import java.sql.SQLException;
import java.util.List;

import com.cg.bean.EmpBean;
import com.cg.dao.EmpDaoImpl;
import com.cg.dao.IEmpDao;
import com.cg.exception.EmpException;

public class EmpserviceImpl implements IEmpservice {
	IEmpDao empdao = new EmpDaoImpl();

	@Override
	public Boolean addEmployeeDetails(EmpBean emplo) throws SQLException, EmpException {
		
		return empdao.addEmployeeDetails(emplo);
	}

	@Override
	public List<EmpBean> displayEmployeeDetails() throws EmpException {
		
		return empdao.displayEmployeeDetails();
	}

	@Override
	public void deleteEmployeeDetails(Integer empid1) throws SQLException, EmpException {
	
		  empdao.deleteEmployeeDetails(empid1);
			
		
	}

	@Override
	public void updateSalary(String saly, int empid2) throws SQLException, EmpException {
		  empdao.updateSalary(saly,empid2);
		
	}

	
		
		

	

}
