package com.cg.dao;

public interface QueryMapper {
	
	public static final String ADD_EMPLOYEE_DETAILS="INSERT INTO Employee VALUES(?,?,?,?)";
	public static final String DISPLAY_EMP_DETAILS="SELECT * FROM Employee";
	public static final String DELETE_EMP_DETAILS="DELETE FROM EMPLOYEE WHERE EMP_ID=?";
	public static final String UPDATE_SALARY="UPDATE Employee set emp_sal=? where emp_id =?";



}
